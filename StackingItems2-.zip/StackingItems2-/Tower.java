import javax.swing.JOptionPane;

/**
 * Clase Tower - Simulador visual de torre de tazas apiladas.
 *
 * CICLO 1: pushCup, popCup, peekCup, removeCup, pushLid, popLid, removeLid,
 *          orderTower, reverseTower, height, lidedCups, stackingItems,
 *          makeVisible, ok
 *
 * CICLO 2: Tower(cups), swap(String[], String[]), cover(),
 *          swapToReduce(), exit()
 *
 * Proyecto: stackingItems
 */
public class Tower
{
    private static final int GROUND_Y = 280;
    private static final int CENTER_X = 120;

    private int     towerWidth;
    private int     maxHeight;
    private Cup[]   cups;
    private Lid[]   lids;
    private int     size;
    private boolean makeVisible;
    private boolean ok;

    // ─── Constructor ciclo 1 ──────────────────────────────────────
    /**
     * Crea una torre vacía con ancho y altura máxima.
     * @param towerWidth ancho referencial (cm)
     * @param maxHeight  altura máxima permitida (cm)
     */
    public Tower(int towerWidth, int maxHeight)
    {
        this.towerWidth  = towerWidth;
        this.maxHeight   = maxHeight;
        this.cups        = new Cup[100];
        this.lids        = new Lid[100];
        this.size        = 0;
        this.makeVisible = true;
        this.ok          = false;
    }

    /**
     * [Req 10] create(n) - Crea la torre automaticamente con n tazas (mayor a menor).
     * Borra la torre anterior si existia.
     * @param n numero de tazas a crear
     */
    public void create(int n)
    {
        eraseAll();
        size = 0;
        for (int i = 0; i < 100; i++) { cups[i] = null; lids[i] = null; }
        for (int i = n; i >= 1; i--) {
            cups[size] = new Cup(i);
            lids[size] = null;
            size++;
        }
        if (makeVisible) redraw();
        ok = true;
    }

    //  CICLO 2 — NUEVOS MÉTODOS
    
    /**
     * [Req 11] Intercambia la posición de dos objetos en la torre.
     * Los objetos se identifican por tipo y número.
     *
     * @param o1 objeto 1: {"cup","4"} o {"lid","4"}
     * @param o2 objeto 2: {"cup","3"} o {"lid","3"}
     *
     */
    public void swap(String[] o1, String[] o2)
    {
        if (o1 == null || o2 == null || o1.length < 2 || o2.length < 2) {
            ok = false; return;
        }
        String type1 = o1[0]; int num1 = Integer.parseInt(o1[1]);
        String type2 = o2[0]; int num2 = Integer.parseInt(o2[1]);

        int idx1 = findCup(num1);
        int idx2 = findCup(num2);
        if (idx1 == -1 || idx2 == -1) { ok = false; return; }

        if (type1.equals("cup") && type2.equals("cup")) {
            // Intercambiar tazas completas (taza + su tapa)
            Cup tc = cups[idx1]; cups[idx1] = cups[idx2]; cups[idx2] = tc;
            Lid tl = lids[idx1]; lids[idx1] = lids[idx2]; lids[idx2] = tl;

        } else if (type1.equals("lid") && type2.equals("lid")) {
            // Intercambiar solo las tapas
            Lid tl = lids[idx1]; lids[idx1] = lids[idx2]; lids[idx2] = tl;

        } else {
            // cup <-> lid: la tapa de la taza indicada en lid va a la taza de cup
            int idxCup = type1.equals("cup") ? idx1 : idx2;
            int idxLid = type1.equals("lid") ? idx1 : idx2;
            Lid tl = lids[idxCup]; lids[idxCup] = lids[idxLid]; lids[idxLid] = tl;
        }

        if (makeVisible) redraw();
        ok = true;
    }

    /**
     * [Req 12] Cubre todas las tazas sin tapa.
     * Usa el mismo color de cada taza para su tapa.
     */
    public void cover()
    {
        for (int i = 0; i < size; i++) {
            if (lids[i] == null) {
                lids[i] = new Lid(cups[i].getColor());
            }
        }
        if (makeVisible) redraw();
        ok = true;
    }

    /**
     * [Req 13] Retorna los intercambios que reducirían la altura de la torre.
     *
     *
     * Si no hay reducción posible, retorna arreglo vacío String[0][5].
     *
     * Ej de resultado: {{"cup","4"},{"lid","4"}} → intercambiar taza 4 con tapa 4
     * Según enunciado: swapToReduce. Los objetos a intercambiar se identifican
     * por tipo y número. Ej: {{"cup","4"},{"lid","4"}}
     */
    public String[][] swapToReduce()
    {
        if (size < 2) { ok = false; return new String[0][5]; }

        int currentHeight = height();
        int count = 0;

        // Primera pasada: contar cuántos swaps reducen la altura
        for (int i = 0; i < size; i++)
            for (int j = i + 1; j < size; j++)
                if (currentHeight - simulateSwapHeight(i, j) > 0) count++;

        String[][] result = new String[count][5];
        int r = 0;
        for (int i = 0; i < size; i++) {
            for (int j = i + 1; j < size; j++) {
                int reduction = currentHeight - simulateSwapHeight(i, j);
                if (reduction > 0) {
                    result[r][0] = "cup";
                    result[r][1] = String.valueOf(cups[i].getNumber());
                    result[r][2] = "cup";
                    result[r][3] = String.valueOf(cups[j].getNumber());
                    result[r][4] = String.valueOf(reduction);
                    r++;
                }
            }
        }
        ok = true;
        return result;
    }

    // ═══════════════════════════════════════════════════════════════
    //  CICLO 1 — MÉTODOS ORIGINALES
    // ═══════════════════════════════════════════════════════════════

    public void pushCup(int cup)
    {
        if (!canFit(cup)) {
            ok = false;
            if (makeVisible)
                JOptionPane.showMessageDialog(null,
                    "La taza " + cup + " no cabe. Altura max: " + maxHeight + " cm.");
            return;
        }
        cups[size] = new Cup(cup);
        lids[size] = null;
        size++;
        if (makeVisible) redraw();
        ok = true;
    }

    public int popCup()
    {
        if (size == 0) { ok = false; return -1; }
        size--;
        cups[size].undraw();
        if (lids[size] != null) lids[size].undraw();
        int removed = cups[size].getNumber();
        cups[size] = null;
        lids[size] = null;
        if (makeVisible) redraw();
        ok = true;
        return removed;
    }

    public int peekCup()
    {
        if (size == 0) { ok = false; return -1; }
        ok = true;
        return cups[size - 1].getNumber();
    }

    public void removeCup(int cup)
    {
        int idx = findCup(cup);
        if (idx == -1) { ok = false; return; }
        cups[idx].undraw();
        if (lids[idx] != null) lids[idx].undraw();
        for (int i = idx; i < size - 1; i++) {
            cups[i] = cups[i + 1];
            lids[i] = lids[i + 1];
        }
        size--;
        cups[size] = null;
        lids[size] = null;
        if (makeVisible) redraw();
        ok = true;
    }

    public void pushLid(int cup, String color)
    {
        int idx = findCup(cup);
        if (idx == -1) { ok = false; return; }
        if (lids[idx] != null) lids[idx].undraw();
        lids[idx] = new Lid(color);
        if (makeVisible) redraw();
        ok = true;
    }

    public String popLid(int cup)
    {
        int idx = findCup(cup);
        if (idx == -1 || lids[idx] == null) { ok = false; return ""; }
        String color = lids[idx].getColor();
        lids[idx].undraw();
        lids[idx] = null;
        if (makeVisible) redraw();
        ok = true;
        return color;
    }



    public void orderTower()
    {
        eraseAll();
        for (int i = 0; i < size - 1; i++)
            for (int j = 0; j < size - 1 - i; j++)
                if (cups[j].getNumber() > cups[j+1].getNumber()) {
                    Cup tc = cups[j]; cups[j] = cups[j+1]; cups[j+1] = tc;
                    Lid tl = lids[j]; lids[j] = lids[j+1]; lids[j+1] = tl;
                }
        if (makeVisible) redraw();
        ok = true;
    }

    public void reverseTower()
    {
        eraseAll();
        for (int i = 0; i < size / 2; i++) {
            Cup tc = cups[i]; cups[i] = cups[size-1-i]; cups[size-1-i] = tc;
            Lid tl = lids[i]; lids[i] = lids[size-1-i]; lids[size-1-i] = tl;
        }
        if (makeVisible) redraw();
        ok = true;
    }

    public int height()
    {
        if (size == 0) return 0;
        
        int total = cups[0].getHeight();
        for (int i = 1; i < size; i++)
            total += cups[i].getHeight() - 1;
        
        if (lids[size - 1] != null)
            total += 1;
        return total;
    }

    public int[] lidedCups()
    {
        int count = 0;
        for (int i = 0; i < size; i++) if (lids[i] != null) count++;
        int[] result = new int[count];
        int j = 0;
        for (int i = 0; i < size; i++) if (lids[i] != null) result[j++] = cups[i].getNumber();
        for (int i = 0; i < result.length - 1; i++)
            for (int k = 0; k < result.length - 1 - i; k++)
                if (result[k] < result[k+1]) { int t = result[k]; result[k] = result[k+1]; result[k+1] = t; }
        ok = true;
        return result;
    }

    public String[][] stackingItems()
    {
        String[][] copy = new String[size][2];
        for (int i = 0; i < size; i++) {
            copy[i][0] = String.valueOf(cups[i].getNumber());
            copy[i][1] = (lids[i] != null) ? lids[i].getColor() : "";
        }
        ok = true;
        return copy;
    }

    public void makeVisible(boolean visible)
    {
        if (!visible) {
            JOptionPane.showMessageDialog(null,
                "El simulador no se puede ocultar en esta version.");
            ok = false;
            return;
        }
        this.makeVisible = visible;
        redraw();
        ok = true;
    }

    /**
     * Cambia la visibilidad internamente sin mostrar dialogo.
     * Uso exclusivo para pruebas de unidad (modo invisible).
     * @param visible true=visible, false=invisible
     */
    public void setVisibleForTest(boolean visible)
    {
        this.makeVisible = visible;
        ok = true;
    }

    /**
     * Cierra el simulador: borra todas las tazas del canvas
     * y cierra la ventana de BlueJ Shapes Demo.
     */
    public void exit()
    {
        eraseAll();
        Canvas canvas = Canvas.getCanvas();
        canvas.setVisible(false);
        ok = true;
    }

    public boolean ok() { return ok; }
    
    //  DIBUJO
    private void redraw()
    {
        eraseAll();
        int currentBottomY = GROUND_Y;
        for (int i = 0; i < size; i++) {
            cups[i].draw(CENTER_X, currentBottomY);
            if (lids[i] != null)
                lids[i].draw(cups[i], CENTER_X, currentBottomY);
            currentBottomY -= (cups[i].getHeight() - 1) * Cup.SCALE;
        }
    }

    private void eraseAll()
    {
        for (int i = 0; i < size; i++) {
            if (cups[i] != null) cups[i].undraw();
            if (lids[i] != null) lids[i].undraw();
        }
    }

    //  AUXILIARES

    /**
     * Simula swap entre posiciones i y j, retorna la altura resultante.
     * Incluye el efecto de la tapa en el tope.
     */
    private int simulateSwapHeight(int i, int j)
    {
        int[] heights  = new int[size];
        boolean[] hasLid = new boolean[size];
        for (int k = 0; k < size; k++) {
            heights[k]  = cups[k].getHeight();
            hasLid[k]   = (lids[k] != null);
        }

        int tmpH = heights[i]; heights[i] = heights[j]; heights[j] = tmpH;
        boolean tmpL = hasLid[i]; hasLid[i] = hasLid[j]; hasLid[j] = tmpL;

        int total = heights[0];
        for (int k = 1; k < size; k++) total += heights[k] - 1;
        if (hasLid[size - 1]) total += 1;
        return total;
    }

    private boolean canFit(int cup)
    {
        int h = 2 * cup - 1;
        int projected = (size == 0) ? h : height() + h - 1;
        return projected <= maxHeight;
    }

    private int findCup(int cup)
    {
        for (int i = 0; i < size; i++)
            if (cups[i].getNumber() == cup) return i;
        return -1;
    }

    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Tower ===\n")
          .append("Altura max: ").append(maxHeight).append(" cm | ")
          .append("Altura actual: ").append(height()).append(" cm\n")
          .append("Tazas (base -> tope):\n");
        for (int i = 0; i < size; i++) {
            sb.append("  ").append(i+1).append(". ").append(cups[i]);
            if (lids[i] != null) sb.append(" | ").append(lids[i]);
            sb.append("\n");
        }
        return sb.toString();
    }
}