/**
 * Clase Cup - Taza individual de la torre (forma de U).
 * Usa 3 Rectangle de zShapes.
 * Proyecto: stackingItems
 */
public class Cup
{
    public static final int SCALE    = 20;
    public static final int CUP_STEP = 25;
    public static final int WALL_W   = 12;
    public static final int BASE_H   =  8;
    public static final int BORN_X   = 70;
    public static final int BORN_Y   = 15;

    private int     number;
    private String  color;
    private boolean visible;

    private Rectangle leftWall;
    private Rectangle rightWall;
    private Rectangle baseRect;

    private int lwX, lwY;
    private int rwX, rwY;
    private int brX, brY;

    public Cup(int number)
    {
        this.number    = number;
        this.color     = colorFor(number);
        this.visible   = false;
        this.leftWall  = new Rectangle();
        this.rightWall = new Rectangle();
        this.baseRect  = new Rectangle();
        this.lwX = BORN_X; this.lwY = BORN_Y;
        this.rwX = BORN_X; this.rwY = BORN_Y;
        this.brX = BORN_X; this.brY = BORN_Y;
    }

    public int    getNumber()   { return number; }
    public String getColor()    { return color; }
    public int    getHeight()   { return 2 * number - 1; }
    public int    getHeightPx() { return getHeight() * SCALE; }
    public int    getWidthPx()  { return number * CUP_STEP; }

    public void draw(int centerX, int bottomY)
    {
        int totalW = getWidthPx();
        int totalH = getHeightPx();
        int wallH  = totalH - BASE_H;
        int leftX  = centerX - totalW / 2;
        int topY   = bottomY - totalH;

        leftWall.makeInvisible();
        leftWall.changeSize(wallH, WALL_W);
        leftWall.changeColor(color);

        rightWall.makeInvisible();
        rightWall.changeSize(wallH, WALL_W);
        rightWall.changeColor(color);

        baseRect.makeInvisible();
        baseRect.changeSize(BASE_H, totalW);
        baseRect.changeColor(color);

        leftWall.moveHorizontal(leftX - lwX);
        leftWall.moveVertical(topY - lwY);
        lwX = leftX; lwY = topY;

        int rwTargetX = leftX + totalW - WALL_W;
        rightWall.moveHorizontal(rwTargetX - rwX);
        rightWall.moveVertical(topY - rwY);
        rwX = rwTargetX; rwY = topY;

        int brTargetY = topY + wallH;
        baseRect.moveHorizontal(leftX - brX);
        baseRect.moveVertical(brTargetY - brY);
        brX = leftX; brY = brTargetY;

        leftWall.makeVisible();
        rightWall.makeVisible();
        baseRect.makeVisible();
        visible = true;
    }

    public void undraw()
    {
        leftWall.makeInvisible();
        rightWall.makeInvisible();
        baseRect.makeInvisible();
        visible = false;
    }

    public boolean isVisible() { return visible; }

    private String colorFor(int n)
    {
        switch (n % 6) {
            case 1:  return "cyan";
            case 2:  return "green";
            case 3:  return "red";
            case 4:  return "blue";
            case 5:  return "yellow";
            case 0:  return "magenta";
            default: return "blue";
        }
    }

    @Override
    public String toString()
    {
        return "Cup #" + number + " (h=" + getHeight() + "cm, color=" + color + ")";
    }
}