/**
 * Clase Lid - Tapa de una taza 
 * Proyecto: stackingItems
 */
public class Lid
{
    public static final int LID_H = 1 * Cup.SCALE;

    private String    color;
    private boolean   visible;
    private Rectangle rect;
    private int curX, curY;

    public Lid(String color)
    {
        this.color   = color;
        this.visible = false;
        this.rect    = new Rectangle();
        this.curX    = Cup.BORN_X;
        this.curY    = Cup.BORN_Y;
    }

    public String  getColor()  { return color; }
    public boolean isVisible() { return visible; }

    public void draw(Cup cup, int centerX, int bottomY)
    {
        int w       = cup.getWidthPx();
        int leftX   = centerX - w / 2;
        int targetY = bottomY - cup.getHeightPx() - LID_H;

        rect.makeInvisible();
        rect.changeSize(LID_H, w);
        rect.changeColor(color);
        rect.moveHorizontal(leftX   - curX);
        rect.moveVertical(targetY   - curY);
        curX = leftX;
        curY = targetY;
        rect.makeVisible();
        visible = true;
    }

    public void undraw()
    {
        rect.makeInvisible();
        visible = false;
    }

    @Override
    public String toString() { return "Lid(color=" + color + ")"; }
}