/**
 * Representa una tapa para una taza.
 */
public class Lid
{
    private Rectangle shape;
    private int number;
    private int height;
    private String color;

    public Lid(int number, String color)
    {
        this.number = number;
        this.color = color;
        height = 8;

        shape = new Rectangle();
        shape.changeColor(color);
        shape.changeSize(height, 20);
    }

    public void drawAt(int x, int y)
    {
        shape.makeInvisible();
        shape.makeVisible();
        shape.moveHorizontal(x);
        shape.moveVertical(y);
    }

    public int getHeight()
    {
        return height;
    }

    public int getNumber()
    {
        return number;
    }

    public void makeInvisible()
    {
        shape.makeInvisible();
    }
}
