/**
 * Clase Cup.
 * Representa una taza que puede ser apilada dentro de la torre.
 */
public class Cup
{
    /** Representación gráfica de la taza */
    private Circle shape;

    /** Número identificador de la taza */
    private int number;

    /** Altura de la taza */
    private int height;

    /** Color de la taza */
    private String color;
    /**
    * Constructor de la clase Cup.
    * 
    * @param number número identificador de la taza
    * @param color color de la taza
    */
    public Cup(int number, String color)
    {
    this.number = number;
    this.color = color;
    height = 20;

    shape = new Circle();
    shape.changeColor(color);
    shape.changeSize(height);
    }
    /**
    * Dibuja la taza en la posición indicada.
    * 
    * @param x posición horizontal
    * @param y posición vertical
    */
    public void drawAt(int x, int y)
    {
    shape.makeInvisible();   // reinicia posición visual
    shape.makeVisible();
    shape.moveHorizontal(x);
    shape.moveVertical(y);
    }
    public int getWidth()
    {
    return height;
    }


    /**
    * Retorna la altura de la taza.
    */
    public int getHeight()
    {
    return height;
    }

    /**
    * Retorna el número de la taza.
    */
    public int getNumber()
    {
    return number;
    }
    public void makeInvisible()
    {
    shape.makeInvisible();
    }



}
