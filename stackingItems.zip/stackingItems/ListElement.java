/**
 * Clase ListElement.
 * 
 * Representa un nodo de una lista enlazada que almacena
 * un elemento de la torre y la referencia al siguiente.
 */
public class ListElement
{
    /** Dato almacenado (Cup o Lid posteriormente) */
    private Object data;

    /** Referencia al siguiente elemento */
    private ListElement next;

    /**
     * Constructor del nodo.
     * 
     * @param data elemento a almacenar
     * @param next siguiente elemento en la lista
     */
    public ListElement(Object data, ListElement next)
    {
        this.data = data;
        this.next = next;
    }

    /**
     * Retorna el dato almacenado.
     */
    public Object getData()
    {
        return data;
    }

    /**
     * Retorna el siguiente elemento.
     */
    public ListElement getNext()
    {
        return next;
    }

    /**
     * Cambia la referencia al siguiente elemento.
     */
    public void setNext(ListElement next)
    {
        this.next = next;
    }
}
