/**
 * Clase Tower.
 * 
 * Representa la torre del simulador donde posteriormente se
 * apilarán tazas y tapas. La torre define un ancho y una altura
 * máxima y puede hacerse visible o invisible.
 * 
 * 
 * @author Francisco Gomez - Oscar Lopez
 * @version 2026
 */
public class Tower
{
    /* ===================== ATRIBUTOS ===================== */
    private int width;

    private int maxHeight;

    private boolean visible;

    private boolean ok;

    private Canvas canvas;
    
    private Rectangle structure;

    private int currentHeight;
    
    private int baseX;

    private int baseY;
    
    private ListElement top;


    /* ===================== CONSTRUCTOR ===================== */

    /**
     * Constructor de la clase Tower.
     * Crea una torre con un ancho y una altura máxima definidos.
     * Inicialmente la torre no es visible.
     * 
     * @param width ancho de la torre
     * @param maxHeight altura máxima de la torre
     */
    public Tower(int width, int maxHeight)
    {
        this.width = width;
        this.maxHeight = maxHeight;
        visible = false;
        ok = true;
        currentHeight = 0;

        canvas = Canvas.getCanvas();

        baseX = 100;
        baseY = maxHeight + 50;

        structure = new Rectangle();
        prepareStructure();
    }


    /* ===================== MÉTODOS PRIVADOS ===================== */
    private void prepareStructure()
    {
        structure.changeSize(maxHeight, width);
        structure.changeColor("black");
    }
    private void redraw()
    {
    if(!visible) return;

    structure.makeVisible();
    drawCups();
    }
    private void drawCups()
    {
    ListElement current = top;
    int accumulatedHeight = 0;

    while(current != null)
    {
        Cup cup = (Cup) current.getData();

        int y = baseY - accumulatedHeight - cup.getHeight();
        int x = baseX + (width / 2) - (cup.getWidth() / 2);
        cup.drawAt(x, y);


        accumulatedHeight += cup.getHeight();
        current = current.getNext();
    }
    }




    /* ===================== MÉTODOS PÚBLICOS ===================== */
    public void makeVisible()
    {
        visible = true;
        redraw();
    }
    public void makeInvisible()
    {
        visible = false;
        structure.makeInvisible();
    }
    public int height()
    {
        return currentHeight;
    }
    public boolean getOk()
    {
        return ok;
    }
    public void finish()
    {
        makeInvisible();
        canvas.setVisible(false);
    } 
    
    public void pushLid(Lid lid)
    {
        if(currentHeight + lid.getHeight() > maxHeight)
        {
            ok = false;
            return;
        }

        top = new ListElement(lid, top);
        currentHeight += lid.getHeight();
        ok = true;
        redraw();
    }
    
    public void pushCup(Cup cup)
    {
    if(currentHeight + cup.getHeight() > maxHeight)
    {
        ok = false;
        return;
    }

    top = new ListElement(cup, top);
    currentHeight += cup.getHeight();

    ok = true;
    redraw();
    }

}
